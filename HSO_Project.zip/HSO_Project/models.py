"""
This file defines the database models
"""

import datetime
import uuid
from .common import db, Field, auth
from pydal.validators import *


def get_user_email():
    return auth.current_user.get('email') if auth.current_user else None

def get_time():
    return datetime.datetime.utcnow()

def get_user():
    return auth.current_user.get('id') if auth.current_user else None

def get_uuid():
    return uuid.uuid4()
### Define your table below
#
# db.define_table('thing', Field('name'))
#
## always commit your models to avoid problems later

# db.define_table(
#     'contact',
#     Field('first_Name', requires=IS_NOT_EMPTY()),
#     Field('last_Name', requires=IS_NOT_EMPTY()),
#     Field('user_Email', default=get_user_email),
#     Field('post_content')
# )

# db.define_table(
#     'thumbs',
#     Field('post_id', 'reference contact'),
#     Field('rating_up', 'boolean', default=None),
#     Field('rating_down', 'boolean', default=None),
#     Field('rater', 'reference auth_user', default=get_user)
# )

# db.define_table(
#     'rater_person',
#     Field('rate_id','reference thumbs'),
#     Field('first_Name'),
#     Field('last_Name')
# )


###
#    头像图片（可选）
###


db.define_table(
    'user',
    Field('first_name', requires=IS_NOT_EMPTY()),
    Field('last_name', requires=IS_NOT_EMPTY()),
    Field('uuid', requires=IS_NOT_EMPTY()),
    Field('email', requires=IS_NOT_EMPTY()),
)

db.define_table(
    'user_option_Info',
    Field('user_id', 'reference user'),
    Field('nickname'),
    Field('sex'),
    Field('day'),
    Field('month'),
    Field('year'),
    Field('age'),
    Field('zip_code')
)


db.user_option_Info.user_id.readable = db.user_option_Info.user_id.writable = False

# db.define_table(
#     'commodity',
#     Field('type', requires=IS_NOT_EMPTY()),

# )





db.commit()
